<!DOCTYPE html>
<html>

<head>
    <title>Masuk</title>
    <link rel="stylesheet" type="text/css" href="css/style-login.css" >
</head>

<body>
    <div class="form-container">
        <div class="user-img"></div>
        <ul class="list">
            <li>
                <h2>Masuk</h2>
            </li>
            <form>
            <li><input type="text" name="Nama Pengguna" placeholder="Nama Pengguna"></li>
            <li><input type="password" name="Kata Sandi" placeholder="Kata Sandi"></li>
            <li style="text-align: right">Lupa Kata Sandi?</li>
            <li><input type="button" name="Masuk" value="Masuk"></li>
            <li>Belum Punya Akun?<a href="/register" > Daftar Sekarang</a></li>
            </form>
        </ul>
    </div>
    <div class="bg-login"></div>
</body>


</html>
<?php /**PATH C:\xampp2\htdocs\web_akun\resources\views/login.blade.php ENDPATH**/ ?>